from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes import router  # Assurez-vous d'importer vos routes

app = FastAPI()

# Configuration CORS
origins = [
    "http://localhost:3000",  # React en local
    "http://localhost:5173",  # Vite.js en local
    "http://127.0.0.1:3000",  # React en local sur IP
    "http://127.0.0.1:5173",  # Vite.js en local sur IP
    "https://mon-site-en-production.com",  # URL en production
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # Autoriser les origines spécifiées
    allow_credentials=True,  # Pour les cookies et sessions
    allow_methods=["*"],  # Toutes les méthodes HTTP
    allow_headers=["*"],  # Tous les headers
)

# Inclure les routes
app.include_router(router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
