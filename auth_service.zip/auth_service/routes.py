from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from schemas import UserCreate,UserLogin,UserProfile, UpdateUserProfile
from models import User
from utils import hash_password, verify_password, create_jwt, decode_jwt
from database import get_db


router = APIRouter()

@router.post("/signup", response_model=UserProfile)
def signup(user: UserCreate, db:Session=Depends(get_db)):
    db_user=db.query(User).filter(User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password=hash_password(user.password)
    new_user=User(email=user.email,password_hash=hashed_password,role=user.role)

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return UserProfile(id=new_user.id,email=new_user.email,role=new_user.role,signup_date=new_user.signup_date.isoformat())

@router.post("/login")
def login(user:UserLogin,db:Session=Depends(get_db)):
    db_user=db.query(User).filter(User.email==user.email).first()
    if not db_user or not verify_password(user.password,db_user.password_hash):
        raise HTTPException(status_code=400,detail="Incorrect email or password")
    
    token = create_jwt({"user_id":db_user.id, "role": db_user.role})
    return {"access_toke": token, "token_type":"bearer"}

@router.get("/user-profile", response_model=UserProfile)
def get_user_profile(token:str=Depends(decode_jwt),db:Session=Depends(get_db)):
    if not token:
        raise HTTPException(status_code=401,detail="Invalid or expired token")
    
    user_id=token["user_id"]
    user=db.query(User).filter(User.id==user_id).first()

    if not user:
        raise HTTPException(status_code=404,detail="User not found")
    return UserProfile(id=user.id,email=user.email,role=user.role,signup_date=user.signup_date.isoformat())

@router.put("/user-profile/update")
def update_user_profile(update_data: UpdateUserProfile, token:str =Depends(decode_jwt), db:Session=Depends(get_db)):
    if not token:
        raise HTTPException(status_code=401,detail="Invalid or expired token")
    
    user_id=token["user_id"]
    user=db.query(User).filter(User.id==user_id).first()

    if not user:
        raise HTTPException(status_code=404,detail="User not found")
    
    if update_data.email:
        user.email = update_data.email
        return("Email successfully updated")
    if update_data.password:
        user.password_hash = hash_password(update_data.password)
        return("Password successfully updated")
    if update_data.role:
        user.role = update_data.role
        return("Role successfully updated")

    db.commit()
    db.refresh(user)
    
    
    
